<?php if ( ! is_active_sidebar( 'spintech-sidebar-primary' ) ) {	return; } ?>
<div class="col-lg-4 pl-lg-4 order-0">
	<div class="sidebar">
		<?php dynamic_sidebar('spintech-sidebar-primary'); ?>
	</div>
</div>